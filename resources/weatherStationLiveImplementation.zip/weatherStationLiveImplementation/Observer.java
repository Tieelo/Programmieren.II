package ProgrammierungII.designPatterns.observer.weatherStationLiveImplementation;

public interface Observer {
	void update(float temp, float humidity, float pressure);
}
